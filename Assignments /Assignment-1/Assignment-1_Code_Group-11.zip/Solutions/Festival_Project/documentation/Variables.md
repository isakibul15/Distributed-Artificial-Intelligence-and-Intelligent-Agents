# Documentation of Variables

[comment]:This file is generated at the creation of the model file. Feel free to modify it in any way you want. 
---

## Author
### md.sakibulislam

## Description

Based on the internal skeleton template.

## Elements

[See structure](Variables_structure.md)

